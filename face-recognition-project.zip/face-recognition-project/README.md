# FaceID – Face Recognition System

A web-based face recognition project.

- **Frontend:** HTML, CSS, JavaScript (webcam via `getUserMedia`)
- **Backend:** Python, Flask, OpenCV (Haar Cascade detection + LBPH recognition)
- **Database:** SQLite (users + attendance log)

## Project Structure

```
face-recognition-project/
├── backend/
│   ├── app.py            # Flask REST API + serves frontend
│   ├── face_engine.py    # detection, training, recognition
│   ├── database.py       # SQLite helpers
│   └── requirements.txt
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── script.js
└── README.md
```

## How to Run

1. Install Python 3.9+.
2. Open a terminal in the `backend` folder:

```bash
cd backend
python -m venv venv
venv\Scripts\activate          # Windows
# source venv/bin/activate     # Linux / macOS
pip install -r requirements.txt
python app.py
```

3. Open **http://127.0.0.1:5000** in Chrome/Edge and allow camera access.

## Usage

1. **Register** tab: enter a name, click *Capture & Register* (25 photos are taken automatically).
2. **Recognize** tab: click *Start Camera* – known faces get a green box with name and confidence, unknown faces a red box.
3. **Users** tab: view / delete registered people.
4. **Attendance** tab: every recognized person is logged (once per 5 minutes).

## API Endpoints

| Method | Endpoint             | Purpose                      |
|--------|----------------------|------------------------------|
| POST   | /api/register        | Register user + train model  |
| POST   | /api/recognize       | Recognize faces in a frame   |
| GET    | /api/users           | List users                   |
| DELETE | /api/users/<id>      | Delete user                  |
| GET    | /api/attendance      | Attendance records           |

## Tuning

- If good matches show as "Unknown", raise `DISTANCE_THRESHOLD` in `face_engine.py`.
- If strangers get recognised, lower it.
- Register in the same lighting you will use for recognition.

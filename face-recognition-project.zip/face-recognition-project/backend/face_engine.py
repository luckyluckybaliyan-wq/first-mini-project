"""Face detection + recognition using OpenCV (Haar cascade + LBPH)."""
import base64
import shutil
from pathlib import Path

import cv2
import numpy as np

DATA_DIR = Path(__file__).parent / "data"
FACES_DIR = DATA_DIR / "faces"
MODEL_PATH = DATA_DIR / "model.yml"
FACES_DIR.mkdir(parents=True, exist_ok=True)

FACE_SIZE = (200, 200)
# LBPH "confidence" is a distance: LOWER = better match.
DISTANCE_THRESHOLD = 75.0

_detector = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
)
_recognizer = None


def decode_image(data_url: str) -> np.ndarray:
    """Convert a base64 data-URL (from the browser canvas) into a BGR image."""
    b64 = data_url.split(",", 1)[-1]
    arr = np.frombuffer(base64.b64decode(b64), np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("Could not decode image")
    return img


def detect_faces(gray: np.ndarray):
    gray = cv2.equalizeHist(gray)
    faces = _detector.detectMultiScale(
        gray, scaleFactor=1.2, minNeighbors=5, minSize=(60, 60)
    )
    return [tuple(int(v) for v in f) for f in faces]


def _prepare(gray: np.ndarray, box) -> np.ndarray:
    x, y, w, h = box
    face = cv2.resize(gray[y : y + h, x : x + w], FACE_SIZE)
    return cv2.equalizeHist(face)


def save_samples(user_id: int, images: list) -> int:
    """Detect the largest face in each frame and store it. Returns #saved."""
    folder = FACES_DIR / str(user_id)
    folder.mkdir(parents=True, exist_ok=True)
    saved = 0
    for data_url in images:
        gray = cv2.cvtColor(decode_image(data_url), cv2.COLOR_BGR2GRAY)
        boxes = detect_faces(gray)
        if not boxes:
            continue
        box = max(boxes, key=lambda b: b[2] * b[3])
        cv2.imwrite(str(folder / f"{saved:03d}.jpg"), _prepare(gray, box))
        saved += 1
    return saved


def delete_samples(user_id: int):
    shutil.rmtree(FACES_DIR / str(user_id), ignore_errors=True)


def train() -> int:
    """(Re)train the LBPH model from every stored face. Returns #images used."""
    global _recognizer
    samples, labels = [], []
    for folder in FACES_DIR.iterdir():
        if not folder.is_dir():
            continue
        for img_path in folder.glob("*.jpg"):
            img = cv2.imread(str(img_path), cv2.IMREAD_GRAYSCALE)
            if img is not None:
                samples.append(img)
                labels.append(int(folder.name))
    if not samples:
        _recognizer = None
        MODEL_PATH.unlink(missing_ok=True)
        return 0
    rec = cv2.face.LBPHFaceRecognizer_create(radius=1, neighbors=8, grid_x=8, grid_y=8)
    rec.train(samples, np.array(labels))
    rec.write(str(MODEL_PATH))
    _recognizer = rec
    return len(samples)


def load_model():
    global _recognizer
    if MODEL_PATH.exists():
        _recognizer = cv2.face.LBPHFaceRecognizer_create()
        _recognizer.read(str(MODEL_PATH))


def recognize(data_url: str):
    """Return a list of {box, user_id, distance, confidence} for every face."""
    gray = cv2.cvtColor(decode_image(data_url), cv2.COLOR_BGR2GRAY)
    results = []
    for box in detect_faces(gray):
        entry = {"box": box, "user_id": None, "distance": None, "confidence": 0}
        if _recognizer is not None:
            label, dist = _recognizer.predict(_prepare(gray, box))
            entry["distance"] = round(float(dist), 1)
            entry["confidence"] = max(0, min(100, round(100 - dist)))
            if dist <= DISTANCE_THRESHOLD:
                entry["user_id"] = int(label)
        results.append(entry)
    return results

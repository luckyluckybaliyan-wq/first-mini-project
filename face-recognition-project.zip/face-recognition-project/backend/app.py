"""Flask backend: REST API + serves the static frontend."""
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory

import database as db
import face_engine as engine

FRONTEND_DIR = Path(__file__).resolve().parent.parent / "frontend"
app = Flask(__name__, static_folder=str(FRONTEND_DIR), static_url_path="")

db.init_db()
engine.load_model()


@app.get("/")
def index():
    return send_from_directory(FRONTEND_DIR, "index.html")


@app.post("/api/register")
def register():
    body = request.get_json(silent=True) or {}
    name = (body.get("name") or "").strip()
    images = body.get("images") or []
    if not name:
        return jsonify(error="Name is required"), 400
    if len(images) < 5:
        return jsonify(error="Send at least 5 face images"), 400

    user_id = db.add_user(name)
    saved = engine.save_samples(user_id, images)
    if saved < 5:
        engine.delete_samples(user_id)
        db.delete_user(user_id)
        return jsonify(error=f"Only {saved} clear faces found. Improve lighting and retry."), 422

    engine.train()
    return jsonify(id=user_id, name=name, samples=saved), 201


@app.post("/api/recognize")
def recognize():
    body = request.get_json(silent=True) or {}
    image = body.get("image")
    if not image:
        return jsonify(error="image is required"), 400

    out = []
    for r in engine.recognize(image):
        user = db.get_user(r["user_id"]) if r["user_id"] else None
        logged = db.log_attendance(user["id"]) if user else False
        out.append(
            {
                "box": r["box"],
                "name": user["name"] if user else "Unknown",
                "known": bool(user),
                "confidence": r["confidence"],
                "attendance_logged": logged,
            }
        )
    return jsonify(faces=out)


@app.get("/api/users")
def users():
    return jsonify(users=db.list_users())


@app.delete("/api/users/<int:user_id>")
def remove_user(user_id):
    if not db.get_user(user_id):
        return jsonify(error="User not found"), 404
    engine.delete_samples(user_id)
    db.delete_user(user_id)
    engine.train()
    return jsonify(ok=True)


@app.get("/api/attendance")
def attendance():
    return jsonify(records=db.list_attendance())


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)

"""SQLite helpers: users + attendance log."""
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path

DB_PATH = Path(__file__).parent / "data" / "faces.db"
DB_PATH.parent.mkdir(exist_ok=True)


def _conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with _conn() as c:
        c.execute(
            """CREATE TABLE IF NOT EXISTS users (
                   id INTEGER PRIMARY KEY AUTOINCREMENT,
                   name TEXT NOT NULL,
                   created_at TEXT NOT NULL)"""
        )
        c.execute(
            """CREATE TABLE IF NOT EXISTS attendance (
                   id INTEGER PRIMARY KEY AUTOINCREMENT,
                   user_id INTEGER NOT NULL,
                   seen_at TEXT NOT NULL,
                   FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)"""
        )


def add_user(name):
    with _conn() as c:
        cur = c.execute(
            "INSERT INTO users (name, created_at) VALUES (?, ?)",
            (name, datetime.now().isoformat(timespec="seconds")),
        )
        return cur.lastrowid


def list_users():
    with _conn() as c:
        return [dict(r) for r in c.execute("SELECT * FROM users ORDER BY id DESC")]


def get_user(user_id):
    with _conn() as c:
        row = c.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
        return dict(row) if row else None


def delete_user(user_id):
    with _conn() as c:
        c.execute("DELETE FROM attendance WHERE user_id=?", (user_id,))
        c.execute("DELETE FROM users WHERE id=?", (user_id,))


def log_attendance(user_id, cooldown_minutes=5):
    """Insert an attendance row unless the user was already logged recently."""
    now = datetime.now()
    with _conn() as c:
        last = c.execute(
            "SELECT seen_at FROM attendance WHERE user_id=? ORDER BY id DESC LIMIT 1",
            (user_id,),
        ).fetchone()
        if last and now - datetime.fromisoformat(last["seen_at"]) < timedelta(minutes=cooldown_minutes):
            return False
        c.execute(
            "INSERT INTO attendance (user_id, seen_at) VALUES (?, ?)",
            (user_id, now.isoformat(timespec="seconds")),
        )
        return True


def list_attendance(limit=100):
    with _conn() as c:
        rows = c.execute(
            """SELECT a.id, u.name, a.seen_at FROM attendance a
               JOIN users u ON u.id = a.user_id
               ORDER BY a.id DESC LIMIT ?""",
            (limit,),
        )
        return [dict(r) for r in rows]

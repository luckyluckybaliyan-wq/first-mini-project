// ---------- Tab switching ----------
const tabs = document.querySelectorAll(".tab");
const panels = document.querySelectorAll(".panel");

tabs.forEach((t) =>
  t.addEventListener("click", () => {
    tabs.forEach((x) => x.classList.toggle("active", x === t));
    panels.forEach((p) => p.classList.toggle("active", p.id === t.dataset.tab));
    stopRecognition();
    stopStream(regVideo);
    if (t.dataset.tab === "register") startStream(regVideo);
    if (t.dataset.tab === "users") loadUsers();
    if (t.dataset.tab === "attendance") loadAttendance();
  })
);

// ---------- Camera helpers ----------
async function startStream(video) {
  try {
    video.srcObject = await navigator.mediaDevices.getUserMedia({
      video: { width: 640, height: 480, facingMode: "user" },
    });
    return true;
  } catch (err) {
    alert("Cannot access camera: " + err.message);
    return false;
  }
}

function stopStream(video) {
  if (video.srcObject) {
    video.srcObject.getTracks().forEach((t) => t.stop());
    video.srcObject = null;
  }
}

function grabFrame(video, width = 480) {
  const c = document.createElement("canvas");
  c.width = width;
  c.height = Math.round((video.videoHeight / video.videoWidth) * width);
  c.getContext("2d").drawImage(video, 0, 0, c.width, c.height);
  return { dataUrl: c.toDataURL("image/jpeg", 0.8), w: c.width, h: c.height };
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------- RECOGNIZE ----------
const recVideo = document.getElementById("rec-video");
const overlay = document.getElementById("rec-overlay");
const recToggle = document.getElementById("rec-toggle");
const recStatus = document.getElementById("rec-status");
let recRunning = false;

recToggle.addEventListener("click", async () => {
  if (recRunning) return stopRecognition();
  if (await startStream(recVideo)) {
    recRunning = true;
    recToggle.textContent = "Stop Camera";
    recStatus.textContent = "Scanning...";
    loop();
  }
});

function stopRecognition() {
  recRunning = false;
  stopStream(recVideo);
  overlay.getContext("2d").clearRect(0, 0, overlay.width, overlay.height);
  recToggle.textContent = "Start Camera";
  recStatus.textContent = "Camera is off";
}

async function loop() {
  while (recRunning) {
    if (recVideo.videoWidth) {
      const frame = grabFrame(recVideo);
      try {
        const res = await fetch("/api/recognize", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ image: frame.dataUrl }),
        });
        const data = await res.json();
        if (recRunning) draw(data.faces || [], frame.w, frame.h);
      } catch (e) {
        recStatus.textContent = "Server not reachable";
      }
    }
    await sleep(600);
  }
}

function draw(faces, srcW, srcH) {
  overlay.width = overlay.clientWidth;
  overlay.height = overlay.clientHeight;
  const ctx = overlay.getContext("2d");
  ctx.clearRect(0, 0, overlay.width, overlay.height);

  // video is shown with object-fit: cover, so map coordinates accordingly
  const scale = Math.max(overlay.width / srcW, overlay.height / srcH);
  const offX = (overlay.width - srcW * scale) / 2;
  const offY = (overlay.height - srcH * scale) / 2;

  faces.forEach((f) => {
    const [x, y, w, h] = f.box;
    const color = f.known ? "#4ade80" : "#f87171";
    ctx.strokeStyle = color;
    ctx.lineWidth = 3;
    ctx.strokeRect(x * scale + offX, y * scale + offY, w * scale, h * scale);
    const label = f.known ? `${f.name} (${f.confidence}%)` : "Unknown";
    ctx.font = "16px Segoe UI, Arial";
    const tw = ctx.measureText(label).width + 12;
    ctx.fillStyle = color;
    ctx.fillRect(x * scale + offX, y * scale + offY - 26, tw, 26);
    ctx.fillStyle = "#0f172a";
    ctx.fillText(label, x * scale + offX + 6, y * scale + offY - 8);
  });

  const known = faces.filter((f) => f.known);
  recStatus.textContent = faces.length
    ? known.length
      ? "Recognized: " + known.map((f) => f.name).join(", ")
      : "Face detected – not registered"
    : "No face detected";
}

// ---------- REGISTER ----------
const regVideo = document.getElementById("reg-video");
const regName = document.getElementById("reg-name");
const regStart = document.getElementById("reg-start");
const regBar = document.getElementById("reg-bar");
const regStatus = document.getElementById("reg-status");
const SAMPLES = 25;

regStart.addEventListener("click", async () => {
  const name = regName.value.trim();
  if (!name) return alert("Please enter a name first.");
  if (!regVideo.videoWidth) return alert("Camera is not ready yet.");

  regStart.disabled = true;
  const images = [];
  for (let i = 0; i < SAMPLES; i++) {
    images.push(grabFrame(regVideo).dataUrl);
    regBar.style.width = ((i + 1) / SAMPLES) * 100 + "%";
    regStatus.textContent = `Capturing ${i + 1}/${SAMPLES} – turn your head slightly`;
    await sleep(200);
  }
  regStatus.textContent = "Training model...";
  try {
    const res = await fetch("/api/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, images }),
    });
    const data = await res.json();
    regStatus.textContent = res.ok
      ? `✔ ${data.name} registered with ${data.samples} samples`
      : "✖ " + data.error;
    if (res.ok) regName.value = "";
  } catch (e) {
    regStatus.textContent = "✖ Server not reachable";
  }
  regBar.style.width = "0";
  regStart.disabled = false;
});

// ---------- USERS ----------
async function loadUsers() {
  const { users } = await (await fetch("/api/users")).json();
  const body = document.getElementById("users-body");
  body.innerHTML = users.length
    ? users
        .map(
          (u) => `<tr><td>${u.id}</td><td>${escapeHtml(u.name)}</td><td>${u.created_at}</td>
          <td><button class="del" onclick="deleteUser(${u.id})">Delete</button></td></tr>`
        )
        .join("")
    : `<tr><td colspan="4" class="empty">No users registered yet</td></tr>`;
}

async function deleteUser(id) {
  if (!confirm("Delete this user and their face data?")) return;
  await fetch("/api/users/" + id, { method: "DELETE" });
  loadUsers();
}

// ---------- ATTENDANCE ----------
async function loadAttendance() {
  const { records } = await (await fetch("/api/attendance")).json();
  const body = document.getElementById("att-body");
  body.innerHTML = records.length
    ? records
        .map((r) => `<tr><td>${r.id}</td><td>${escapeHtml(r.name)}</td><td>${r.seen_at}</td></tr>`)
        .join("")
    : `<tr><td colspan="3" class="empty">No attendance recorded yet</td></tr>`;
}

function escapeHtml(s) {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
